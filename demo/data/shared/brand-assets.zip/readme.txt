Fictional demo data: a file type that downloads instead of opening.
